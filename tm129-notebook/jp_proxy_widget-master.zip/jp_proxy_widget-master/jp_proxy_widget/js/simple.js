// a simple javascript file for testing loading

console.log("loading simple javascript");

window.the_answer = 42;

