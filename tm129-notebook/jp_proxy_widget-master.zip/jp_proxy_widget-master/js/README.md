Generic Jupyter/IPython widget implementation that will support many types of javascript libraries and interactions.

Package Install
---------------

**Prerequisites**
- [node](http://nodejs.org/)

```bash
npm install --save jp_proxy_widget
```
