// Shared test globals.

  